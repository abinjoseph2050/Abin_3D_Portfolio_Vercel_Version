### ✅ Form 4: Storage + BigQuery + Entities

- **Create a lake in Dataplex and add a zone to your lake**
- **Attach an existing Cloud Storage bucket to the zone**
- **Attach an existing BigQuery Dataset to the Lake**
- **Create Entities(Manual task)**


### copy the command from here 

```
export ZONE=
```
`````
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/refs/heads/main/Create%20a%20Secure%20Data%20Lake%20on%20Cloud%20Storage%3A%20Challenge%20Lab/ABHIFI4.SH
sudo chmod +x ABHIFI4.SH
./ABHIFI4.SH

`````


### Congratulations !!!!

Connect with fellow cloud enthusiasts, ask questions, and share your learning journey.  

[![Telegram](https://img.shields.io/badge/Telegram_Group-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/+gBcgRTlZLyM4OGI1)
[![YouTube](https://img.shields.io/badge/Subscribe-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@drabhishek.5460?sub_confirmation=1)  

