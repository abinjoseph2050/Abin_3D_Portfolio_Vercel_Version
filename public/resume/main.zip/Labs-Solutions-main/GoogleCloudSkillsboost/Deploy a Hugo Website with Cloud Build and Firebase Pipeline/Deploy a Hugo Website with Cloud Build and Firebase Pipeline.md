## Deploy a Hugo Website with Cloud Build and Firebase Pipeline

##

[![Screenshot-2024-06-30-at-1-46-19-AM.png](https://i.postimg.cc/1z2471v2/Screenshot-2024-06-30-at-1-46-19-AM.png)](https://postimg.cc/hJ8Sh6W1)



```bash
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/refs/heads/main/Deploy%20a%20Hugo%20Website%20with%20Cloud%20Build%20and%20Firebase%20Pipeline/abhishektask1.sh

source abhishektask1.sh
```
***Now Check the score for Task 2 & then go ahead with next Commands.***

##
```bash
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/refs/heads/main/Deploy%20a%20Hugo%20Website%20with%20Cloud%20Build%20and%20Firebase%20Pipeline/abhishektask2.sh

source abhishektask2.sh
```

[![Screenshot-2024-06-29-at-2-47-57-AM.png](https://i.postimg.cc/0NR7rmsb/Screenshot-2024-06-29-at-2-47-57-AM.png)](https://postimg.cc/k2s2p2Dm)

```bash
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/refs/heads/main/Deploy%20a%20Hugo%20Website%20with%20Cloud%20Build%20and%20Firebase%20Pipeline/abhishektask3.sh

source abhishektask3.sh
```

#
### Congratulations !!!!

<div style="text-align: center; display: flex; flex-direction: column; align-items: center; gap: 20px;">
  <p>Connect with fellow cloud enthusiasts, ask questions, and share your learning journey.</p>  

  <a href="https://t.me/+gBcgRTlZLyM4OGI1" target="_blank">
    <img src="https://img.shields.io/badge/Telegram_Group-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white" alt="Telegram">
  </a>

  <a href="https://www.youtube.com/@drabhishek.5460?sub_confirmation=1" target="_blank">
    <img src="https://img.shields.io/badge/Subscribe-FF0000?style=for-the-badge&logo=youtube&logoColor=white" alt="YouTube">
  </a>

  <a href="https://www.instagram.com/drabhishek.5460/" target="_blank">
    <img src="https://img.shields.io/badge/Follow-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" alt="Instagram">
  </a>
</div>
