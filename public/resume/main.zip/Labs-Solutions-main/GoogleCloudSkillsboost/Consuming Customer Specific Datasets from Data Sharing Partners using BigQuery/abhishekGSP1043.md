# Consuming Customer Specific Datasets from Data Sharing Partners using BigQuery 


##  Setup Instructions
### Execute the Following Commands in Cloud Shell & Run these commands in sequence in their respective project consoles:

### 1. Data Sharing Partner Project
```bash
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/main/Consuming%20Customer%20Specific%20Datasets%20from%20Data%20Sharing%20Partners%20using%20BigQuery/ABHISHEK1.SH
chmod +x ABHISHEK1.SH
./ABHISHEK1.SH
```
### Data Publisher Project Console

```
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/refs/heads/main/Consuming%20Customer%20Specific%20Datasets%20from%20Data%20Sharing%20Partners%20using%20BigQuery/ABHISHEK2.SH
sudo chmod +x ABHISHEK2.SH
./ABHISHEK2.SH

```

### Customer (Data Twin) Project Console

```
curl -LO https://raw.githubusercontent.com/Itsabhishek7py/GoogleCloudSkillsboost/refs/heads/main/Consuming%20Customer%20Specific%20Datasets%20from%20Data%20Sharing%20Partners%20using%20BigQuery/abhishek3.sh
sudo chmod +x abhishek3.sh
./abhishek3.sh
```
### Congratulations !!!!

Connect with fellow cloud enthusiasts, ask questions, and share your learning journey.  

[![Telegram](https://img.shields.io/badge/Telegram_Group-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/+gBcgRTlZLyM4OGI1)
[![YouTube](https://img.shields.io/badge/Subscribe-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@drabhishek.5460?sub_confirmation=1)  



